puzzle_config = {
    "dim": 7,
    "nodes": [
        [[6, 6], {"color": "orange"}],
        [[4, 6], {"color": "darkgreen"}],
        [[2, 6], {"color": "darkgreen"}],
        [[1, 6], {"color": "blue"}],
        [[6, 5], {"color": "yellow"}],
        [[4, 5], {"color": "pink"}],
        [[1, 5], {"color": "cyan"}],
        [[2, 4], {"color": "pink"}],
        [[2, 3], {"color": "cyan"}],
        [[0, 3], {"color": "blue"}],
        [[6, 2], {"color": "orange"}],
        [[5, 2], {"color": "red"}],
        [[4, 2], {"color": "yellow"}],
        [[1, 1], {"color": "red"}]
    ]
}
