puzzle_config = {
    "dim": 12,
    "nodes": [
        [[0, 5], {"color": "red"}],
        [[8, 6], {"color": "red"}],
        [[0, 11], {"color": "blue"}],
        [[11, 9], {"color": "blue"}],

        [[1, 9], {"color": "green"}],
        [[5, 0], {"color": "green"}],
        
        [[2, 2], {"color": "yellow"}],
        [[7, 1], {"color": "yellow"}],
        [[3, 3], {"color": "orange"}],
        [[8, 4], {"color": "orange"}],
        [[4, 5], {"color": "purple"}],
        [[8, 8], {"color": "purple"}],

        [[4, 9], {"color": "cyan"}],
        [[9, 8], {"color": "cyan"}],

        [[7, 4], {"color": "pink"}],
        [[8, 5], {"color": "pink"}],

        [[6, 4], {"color": "brown"}],
        [[9, 1], {"color": "brown"}],

        [[9, 0], {"color": "grey"}],
        [[6, 7], {"color": "grey"}]
    ]
}