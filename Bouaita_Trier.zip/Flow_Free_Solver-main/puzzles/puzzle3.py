puzzle_config = {
    "dim": 9,
    "nodes": [
        [[6, 0], {"color": "red"}],
        [[7, 0], {"color": "cyan"}],
        [[8, 0], {"color": "darkgreen"}],
        [[1, 1], {"color": "blue"}],
        [[0, 2], {"color": "brown"}],
        [[3, 2], {"color": "red"}],
        [[3, 3], {"color": "cyan"}],
        [[1, 4], {"color": "darkgreen"}],
        [[7, 4], {"color": "orange"}],
        [[4, 5], {"color": "hotpink"}],
        [[6, 6], {"color": "yellow"}],
        [[8, 6], {"color": "yellow"}],
        [[3, 7], {"color": "brown"}],
        [[6, 7], {"color": "hotpink"}],
        [[7, 7], {"color": "orange"}],
        [[8, 7], {"color": "grey"}],
        [[0, 8], {"color": "blue"}],
        [[5, 8], {"color": "grey"}],
    ]
}
