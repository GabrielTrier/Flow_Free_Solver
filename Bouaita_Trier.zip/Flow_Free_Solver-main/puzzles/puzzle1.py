puzzle_config = {
    "dim": 5,
    "nodes": [
        [[0, 0], {"color": "blue"}],
        [[4, 0], {"color": "yellow"}],
        [[1, 2], {"color": "red"}],
        [[2, 2], {"color": "darkgreen"}],
        [[2, 3], {"color": "blue"}],
        [[0, 4], {"color": "darkgreen"}],
        [[1, 4], {"color": "red"}],
        [[2, 4], {"color": "yellow"}]
    ]
}
